﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace SalesOfMaterials.Classes
{
    public class Materials
    {
        public int idMaterial { get; set; }
        public string Name { get; set; }
        public string DrawingNumber { get; set; }
        public int idType { get; set; }
        public string NameType { get; set; }
        public virtual Types Type { get { return ClassFrame.db.Database.SqlQuery<Types>($"select * from Nomenclature.dbo.Types where idType = {idType}").First(); } }
    }
}

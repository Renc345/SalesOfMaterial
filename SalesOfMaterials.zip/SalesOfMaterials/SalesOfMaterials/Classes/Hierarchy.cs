﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Hierarchy
    {
        public int idHierarchy { get; set; }
        public int idParent { get; set; }
        public int idChild { get; set; }
        public int Quantity { get; set; }
        public virtual ClassMaterials Material { get; set; }
        public virtual ClassMaterials Material1 { get; set; }

    }
}

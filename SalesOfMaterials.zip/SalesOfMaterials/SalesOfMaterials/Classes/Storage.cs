﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Storage
    {
        public int idStorage { get; set; }
        public int idWarehouse { get; set; }
        public int idMaterial { get; set; }
        public int Quantity { get; set; }
        public virtual Warehouses Warehouse { get; set; }
        public virtual Materials Material { get; set; }
    }
}

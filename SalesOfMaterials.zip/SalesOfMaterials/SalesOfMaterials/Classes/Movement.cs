﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Movement
    {
        public int idMovement { get; set; }
        public int idWarehouse { get; set; }
        public int idComposition { get; set; }
        public int idUser { get; set; }
        public int PartOfQuantity { get; set; }
        public bool ArrivalOrExpenditure { get; set; }

        public virtual Warehouses Warehouse { get; set; }
        public virtual ExpenseComposition Expense { get; set; }
        public virtual Employee User { get; set; }
    
    }
}

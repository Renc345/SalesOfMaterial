﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace SalesOfMaterials.Classes
{
    public class ClassMaterials
    {
        public int idMaterial { get; set; }
        public string Name { get; set; }
        public string DrawingNumber { get; set; }
        public int idType { get; set; }
        public virtual Types Type  { get; set; }
    }
}

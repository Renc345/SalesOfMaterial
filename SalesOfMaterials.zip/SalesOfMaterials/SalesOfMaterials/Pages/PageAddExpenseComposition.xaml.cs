﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddExpenseComposition.xaml
    /// </summary>
    public partial class PageAddExpenseComposition : Page
    {
        public int idExpenseIvoices;
        public ExpenseComposition _currentItem = new ExpenseComposition();
        public PageAddExpenseComposition(int id)
        {
            InitializeComponent();
            idExpenseIvoices = id;

            LoadDataGrid(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == idExpenseIvoices).ToList(), 0);
            
            DataContext = _currentItem;
            cmbMaterial.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
        }

        public void LoadDataGrid(List<ExpenseComposition> list, int sort)
        {
            foreach (ExpenseComposition e in list)
                e.Material = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList().FirstOrDefault(x => x.idMaterial == e.IdMaterial);
            if (sort == 0) dgExpenseComposition.ItemsSource = list;
            if (sort == 1) dgExpenseComposition.ItemsSource = list.OrderBy(x => x.Material.Name);
            if (sort == 2) dgExpenseComposition.ItemsSource = list.OrderByDescending(x => x.Material.Name);
        }

        public void LoadDataGridSearch(List<Materials> materials)
        {
            List<ExpenseComposition> list = new List<ExpenseComposition>();
            foreach (ExpenseComposition e in ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == _currentItem.IdExpenseIvoices).ToList())
                if ((from m in materials select m.idMaterial).Contains(e.Material.idMaterial)) list.Add(e);
            foreach (ExpenseComposition e in list)
                e.Material = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList().FirstOrDefault(x => x.idMaterial == e.IdMaterial);
            dgExpenseComposition.ItemsSource = list;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (cmbMaterial.Text == "" || txtQuantity.Text == "" || txtPrice.Text == "")
            {
                MessageBox.Show("Введите данные в поля", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Storage s = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage where idMaterial = @material", new SqlParameter("@material", ((Materials)cmbMaterial.SelectedItem).idMaterial)).FirstOrDefault();
            if (s != null && int.Parse(txtQuantity.Text) > s.Quantity)
            {
                MessageBox.Show($"Количество не может превышать количество хранимое на складе (На складе: {s.Quantity})", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            ExpenseComposition exp = new ExpenseComposition() { IdExpenseComposition = _currentItem.IdExpenseComposition, IdMaterial = (int)_currentItem.IdMaterial, IdExpenseIvoices = idExpenseIvoices, Quantity = _currentItem.Quantity, Price = _currentItem.Price };
            _currentItem = null;
            _currentItem = new ExpenseComposition();
            DataContext = _currentItem;
            if (exp.IdExpenseComposition == 0) ClassFrame.db.ExpenseComposition.Add(exp);
            try
            {
                //ClassFrame.db.Database.ExecuteSqlCommand("update Storage set Quantity = Storage.Quantity - @quantity from Nomenclature.dbo.Storage where idMaterial = @material and  idWarehouse = @warhouse", new SqlParameter("@quantity", exp.Quantity) ,new SqlParameter("@material", exp.IdMaterial), new SqlParameter("@warhouse", exp.IdWarehouse));
                //ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Storage where idMaterial = @material and Quantity = @quantity and idWarehouse = @warhouse", new SqlParameter("@quantity", exp.Quantity), new SqlParameter("@material", exp.IdMaterial), new SqlParameter("@warhouse", exp.IdWarehouse));
                ClassFrame.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            LoadDataGrid(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == idExpenseIvoices).ToList(), 0);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                LoadDataGridSearch(ClassFrame.db.Database.SqlQuery<Materials>($"select * from Nomenclature.dbo.Materials  where Name like '%{txtSearch.Text.ToLower()}%' or DrawingNumber like '%{txtSearch.Text.ToLower()}%'").ToList());
            else LoadDataGrid(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == idExpenseIvoices).ToList(), 0);

        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            LoadDataGrid(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == idExpenseIvoices).ToList(), 1);
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            LoadDataGrid(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == idExpenseIvoices).ToList(), 2);
        }

        private void DgExpenseComposition_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            _currentItem = (ExpenseComposition)dgExpenseComposition.SelectedItem;
            DataContext = _currentItem;
        }
    }
}

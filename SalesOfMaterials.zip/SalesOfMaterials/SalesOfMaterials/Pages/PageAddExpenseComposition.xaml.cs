﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddExpenseComposition.xaml
    /// </summary>
    public partial class PageAddExpenseComposition : Page
    {
        public ExpenseIvoices _currentItem = new ExpenseIvoices();
        public PageAddExpenseComposition(ExpenseIvoices selectedItem)
        {
            InitializeComponent();

                if (selectedItem != null)
                {
                    _currentItem = selectedItem;
                }
            
            List<ExpenseComposition> expenses = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == _currentItem.IdExpenseIvoices).ToList();
            foreach (ExpenseComposition e in expenses)
                e.Material = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList().FirstOrDefault(x => x.idMaterial == e.IdMaterial);
            dgExpenseComposition.ItemsSource = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList(); ;
            DataContext = _currentItem;
            cmbMaterial.ItemsSource = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (cmbMaterial.Text == "" && txtQuantity.Text == "" && txtPrice.Text == "")
            {
                MessageBox.Show("Введите данные в поля", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            ClassMaterials material = (ClassMaterials)cmbMaterial.SelectedItem;
            ExpenseComposition composition = new ExpenseComposition()
            {
                IdMaterial = material.idMaterial,
                IdExpenseIvoices = _currentItem.IdExpenseIvoices,
                Quantity = Convert.ToInt32(txtQuantity.Text),
                Price = Convert.ToDouble(txtPrice.Text)
            };
            try
            {
                ClassFrame.db.ExpenseComposition.Add(composition);
                ClassFrame.db.SaveChanges();
                List<ExpenseComposition> expenses = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == _currentItem.IdExpenseIvoices).ToList();
                foreach (ExpenseComposition item in expenses)
                    item.Material = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList().FirstOrDefault(x => x.idMaterial == item.IdMaterial);
                dgExpenseComposition.ItemsSource = expenses;
                DataContext = _currentItem;
                cmbMaterial.ItemsSource = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            dgExpenseComposition.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList().Where(x => x.Material.Name.ToLower().Contains(txtSearch.Text.ToLower())).ToList();
        }
    }
}

﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMaaterials.xaml
    /// </summary>
    public partial class PageMaaterials : Page
    {
        public PageMaaterials()
        {
            InitializeComponent();
            dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            List<Materials> delet = dgMaterials.SelectedItems.Cast<Materials>().ToList();
            if (MessageBox.Show("Удалить данные", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (Materials s in delet)
                    {
                        ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Storage where idMaterial = @id", new SqlParameter("@id", s.idMaterial));
                        ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Hierarchy where idParent = @id or idChild = @id", new SqlParameter("@id", s.idMaterial));
                        ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Materials where idMaterial = @id", new SqlParameter("@id", s.idMaterial));
                    }
                    MessageBox.Show("Данные удаленны");
                    dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxtMaterial_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtMaterial.Text.Count() != 0) dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").Where(x => x.Name.ToLower().Contains(TxtMaterial.Text.ToLower()) || x.Type.Name.ToLower().Contains(TxtMaterial.Text.ToLower()) || x.DrawingNumber.ToLower().Contains(TxtMaterial.Text.ToLower())).ToList();
            else dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddMaterials(null));

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddMaterials((Materials)dgMaterials.SelectedItem));
        }
    }
}

﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMaaterials.xaml
    /// </summary>
    public partial class PageMaaterials : Page
    {
        public PageMaaterials()
        {
            InitializeComponent();
            LoadDataGrid();
           
        }

        public void LoadDataGrid()
        {
            List<ClassMaterials> list = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList();
            foreach (ClassMaterials s in list)
            {
                s.Type = ClassFrame.db.Database.SqlQuery<Types>("select * from Nomenclature.dbo.Types where idType = @id", new SqlParameter("@id", s.idType)).First();
            }
            dgMaterials.ItemsSource = list;
        }

            private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}

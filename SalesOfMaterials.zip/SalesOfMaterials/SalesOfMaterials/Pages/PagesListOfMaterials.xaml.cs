﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для ListOfMaterials.xaml
    /// </summary>
    public partial class ListOfMaterials : Page
    {
        public ListOfMaterials()
        {
            InitializeComponent();
            LoadDataGrid(ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList());
            
        }

        public void LoadDataGrid(List<Storage> list)
        {
            foreach (Storage s in list)
            {
                s.Warehouse = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses where idWarehouse = @id", new SqlParameter("@id", s.idWarehouse)).First();
                Materials m = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials where idMaterial = @id", new SqlParameter("@id", s.idMaterial)).First();
                m.Type = ClassFrame.db.Database.SqlQuery<Types>("select * from Nomenclature.dbo.Types where idType = @id", new SqlParameter("@id", m.idType)).First();
                s.Material = m;
            }
            dgStorage.ItemsSource = list;
        }

        private void dgStorage_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageStructure((int)((Storage)dgStorage.SelectedItem).idMaterial));
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            var delet = dgStorage.SelectedItems.Cast<Storage>().ToList();
            if(MessageBox.Show("Удалить данные","Внимание",MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (Storage s in delet) ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Storage where idStorage = @id", new SqlParameter("@id", s.idStorage));
                    LoadDataGrid(ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList());
                    MessageBox.Show("Данные удаленны");
                    
                }
                catch ( Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void txtDrawingNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtDrawingNumber.Text.Count() != 0)
                LoadDataGrid(ClassFrame.db.Database.SqlQuery<Storage>($"select S.* from Nomenclature.dbo.Storage S join Nomenclature.dbo.Materials M on S.idMaterial = M.idMaterial where M.DrawingNumber like '%{TxtDrawingNumber.Text.ToLower()}%'").ToList());
            else LoadDataGrid(ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList());

        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("SELECT * FROM Nomenclature.dbo.Materials ORDER BY Name ASC").ToList();
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("SELECT * FROM Nomenclature.dbo.Materials ORDER BY Name DESC").ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddListOfMaterials(null));
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddListOfMaterials((Storage)dgStorage.SelectedItem));
        }
    }
}

﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для ListOfMaterials.xaml
    /// </summary>
    public partial class ListOfMaterials : Page
    {
        public ListOfMaterials()
        {
            InitializeComponent();
            dgStorage.ItemsSource = ClassFrame.db1.Storage.ToList();
        }

        private void dgStorage_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageStructure((int)((Storage)dgStorage.SelectedItem).idMaterial));
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            var delet = dgStorage.SelectedItems.Cast<Storage>().ToList();
            if(MessageBox.Show("Удалить данные","Внимание",MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ClassFrame.db1.Storage.RemoveRange(delet);
                    ClassFrame.db1.SaveChanges();
                    MessageBox.Show("Данные удаленны");
                    dgStorage.ItemsSource = ClassFrame.db1.Storage.ToList();
                }
                catch ( Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}

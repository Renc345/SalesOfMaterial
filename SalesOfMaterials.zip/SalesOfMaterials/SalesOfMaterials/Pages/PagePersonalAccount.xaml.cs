﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePersonalAccount.xaml
    /// </summary>
    public partial class PagePersonalAccount : Page
    {
        Employee _currentUser = ClassFrame.db.Employee.FirstOrDefault(x => x.IdEmployee == Users.GetUsers.ID);
        public PagePersonalAccount()
        {
            InitializeComponent();
            //txtFIO.Text = Users.GetUsers.FIO;
            //txtLogin.Text = Users.GetUsers.Login_Employee;
            //txtPasword.Text = Users.GetUsers.Password_Employee;
            //txtType.Text = Users.GetUsers.Nazv_type;
            DataContext = Users.GetUsers;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    Users.GetUsers.FIO = textBox.Text;
                    txtFIO1.Visibility = Visibility.Hidden;
                    _currentUser.FIO = textBox.Text;
                }
                if (textBox.Name == "txtLogin1")
                {
                    Users.GetUsers.Login_Employee = textBox.Text;
                    txtLogin1.Visibility = Visibility.Hidden;
                    _currentUser.Login_Employee = textBox.Text;
                }
                if (textBox.Name == "txtPasword1")
                {
                    Users.GetUsers.Password_Employee = textBox.Text;
                    txtPasword1.Visibility = Visibility.Hidden;
                    _currentUser.Password_Employee = textBox.Text;
                }
                ClassFrame.db.SaveChanges();
            }
            if (e.Key == Key.LeftCtrl)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    textBox.Text = _currentUser.FIO;
                    txtFIO1.Visibility = Visibility.Hidden;
                }
                if(textBox.Name == "txtLogin1")
                {
                    textBox.Text = _currentUser.Login_Employee;
                    txtLogin1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtPasword1")
                {
                    textBox.Text = _currentUser.Password_Employee;
                    txtPasword1.Visibility = Visibility.Hidden;
                }
            }
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if(e.ClickCount == 2)
            {
                TextBlock textBlock = sender as TextBlock;
                if (textBlock.Name == "txtFIO")
                {
                    txtFIO1.Visibility = Visibility.Visible;
                    txtFIO1.CaretIndex = txtFIO1.Text.Length;
                    txtFIO1.Focus();
                }
                if(textBlock.Name == "txtLogin")
                {
                    txtLogin1.Visibility = Visibility.Visible;
                    txtLogin1.CaretIndex = txtLogin1.Text.Length;
                    txtLogin1.Focus();
                }
                if (textBlock.Name == "txtPasword")
                {
                    txtPasword1.Visibility= Visibility.Visible;
                    txtPasword1.CaretIndex = txtPasword1.Text.Length;
                    txtPasword1.Focus();
                }
            }

        }
    }
}

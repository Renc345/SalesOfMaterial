﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStructure.xaml
    /// </summary>
    public partial class PageStructure : Page
    {

        public readonly ClassMaterials _material = new ClassMaterials();
        public PageStructure(int idMaterial)
        {
            InitializeComponent();
            ClassFrame.db.Database.SqlQuery<Hierarchy>("select * from Nomenclature.dbo.Hierarchy").ToList();
            _material = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Materials.dbo.Storage").FirstOrDefault(x => x.idMaterial == idMaterial);

            foreach (Hierarchy hierarchy in ClassFrame.db.Database.SqlQuery<Hierarchy>("select * from Nomenclature.dbo.Hierarchy").Where(x => x.idParent == _material.idMaterial).ToList())
            {
                TreeViewItem tree = new TreeViewItem();
                tree.Header = hierarchy.Material.Name;
                foreach(Hierarchy hierarchy1 in ClassFrame.db.Database.SqlQuery<Hierarchy>("select * from Nomenclature.dbo.Hierarchy").Where(x => x.idParent == hierarchy.Material.idMaterial).ToList())
                {
                    TreeViewItem tree1 = new TreeViewItem();
                    tree1.Header = hierarchy1.Material.Name;
                    tree.Items.Add(tree1);
                }
                trStructure.Items.Add(tree);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ListOfMaterials());
        }
    }
}

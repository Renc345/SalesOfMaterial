﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStructure.xaml
    /// </summary>
    public partial class PageStructure : Page
    {

        public readonly Materials _material = new Materials();
        public PageStructure(int idMaterial)
        {
            InitializeComponent();
            _material = ClassFrame.db1.Materials.FirstOrDefault(x => x.idMaterial == idMaterial);

            foreach(Hierarchy hierarchy in ClassFrame.db1.Hierarchy.Where(x => x.idParent == _material.idMaterial).ToList())
            {
                TreeViewItem tree = new TreeViewItem();
                tree.Header = hierarchy.Materials.Name;
                foreach(Hierarchy hierarchy1 in ClassFrame.db1.Hierarchy.Where(x => x.idParent == hierarchy.Materials.idMaterial).ToList())
                {
                    TreeViewItem tree1 = new TreeViewItem();
                    tree1.Header = hierarchy1.Materials.Name;
                    tree.Items.Add(tree1);
                }
                trStructure.Items.Add(tree);
            }
        }
    }
}

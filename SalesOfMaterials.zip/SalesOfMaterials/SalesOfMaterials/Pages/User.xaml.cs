﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для User.xaml
    /// </summary>
    public partial class User : Page
    {
        public User()
        {
            InitializeComponent();
            dgUser.ItemsSource = ClassFrame.db.Employee.ToList();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dgUser.ItemsSource = ClassFrame.db.Employee.Where(x => x.FIO.Contains(txtSearch.Text.ToLower()) || x.Login_Employee.Contains(txtSearch.Text.ToLower()) || x.TypesEmployee.Nazv_type.Contains(txtSearch.Text.ToLower())).ToList();
            else dgUser.ItemsSource = ClassFrame.db.Employee.ToList();
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            List<Employee> delet = dgUser.SelectedItems.Cast<Employee>().ToList();
            if (MessageBox.Show("Удалить пользователя", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ClassFrame.db.Employee.RemoveRange(delet);
                    ClassFrame.db.SaveChanges();
                    MessageBox.Show("Данные удаленны");
                    dgUser.ItemsSource = ClassFrame.db.Employee.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnAddUser_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddUser(null));
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddUser((Employee)dgUser.SelectedItem));
        }

        private void MenuFilter_Click(object sender, RoutedEventArgs e)
        {
            MenuItem m = sender as MenuItem;
            switch (m.Header)
            {
                case "Администратор":
                    dgUser.ItemsSource = ClassFrame.db.Employee.Where(x => x.TypesEmployee.Nazv_type == "Администратор").ToList();
                    break;
                case "Сотрудник":
                    dgUser.ItemsSource = ClassFrame.db.Employee.Where(x => x.TypesEmployee.Nazv_type == "Сотрудник").ToList();
                    break;
                case "Кладовщик":
                    dgUser.ItemsSource = ClassFrame.db.Employee.Where(x => x.TypesEmployee.Nazv_type == "Кладовщик").ToList();
                    break;
            }
        }

        private void MenuClear_Click(object sender, RoutedEventArgs e)
        {
            dgUser.ItemsSource = ClassFrame.db.Employee.ToList();
        }
    }
}

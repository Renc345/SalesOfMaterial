﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для DistributionWarehouse.xaml
    /// </summary>
    public partial class DistributionWarehouse : Page
    {
        ExpenseIvoices expense = new ExpenseIvoices();
        public DistributionWarehouse(ExpenseIvoices selected)
        {
            InitializeComponent();
            if(selected != null)
            {
                expense = selected;
            }
            cmbMaterial.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == expense.IdExpenseIvoices).ToList();
        }

        private void cmbMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ExpenseComposition c = cmbMaterial.SelectedItem as ExpenseComposition;
            if (c != null)
            {
                dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial).ToList();
                txtCount.DataContext = ClassFrame.db.ExpenseComposition.FirstOrDefault(x => x.IdExpenseIvoices == expense.IdExpenseIvoices && x.IdMaterial == c.IdMaterial);
                txtCount1.Text = "0";
            }
            quantityComposition.IsReadOnly = false;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            List<Storage> list = dgWarhouse.ItemsSource as List<Storage>;
            foreach (Storage s in list)
            {
                if (s.QuantityComposition > s.Quantity)
                {
                    MessageBox.Show("Количество забираемого товара больше чем количество хранящиеся на складе", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            int quantity = 0;
            foreach (Storage s in list) quantity += s.QuantityComposition;
            if (quantity > Convert.ToInt32(txtCount.Text))
            {
                MessageBox.Show("Количество забираемого товара больше чем нужно", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (quantity < Convert.ToInt32(txtCount.Text))
            {
                MessageBox.Show("Количество забираемого товара меньше чем нужно", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            foreach (Storage s in list)
            {
                try
                {
                    //if (s.QuantityComposition != 0) 
                    ClassFrame.db.Database.ExecuteSqlCommand("insert into Nomenclature.dbo.Movement values (@warehouse,@composition,@user,@quantity,1)", new SqlParameter("@warehouse", s.idWarehouse), new SqlParameter("@composition", ((ExpenseComposition)cmbMaterial.SelectedItem).IdExpenseComposition), new SqlParameter("@user", Users.GetUsers.ID), new SqlParameter("@quantity", s.QuantityComposition));
                    ClassFrame.db.Database.ExecuteSqlCommand("update Storage set Quantity = Storage.Quantity - @quantity from Nomenclature.dbo.Storage where idMaterial = @material and  idWarehouse = @warhouse", new SqlParameter("@quantity",s.QuantityComposition), new SqlParameter("@material", s.idMaterial), new SqlParameter("@warhouse", s.idWarehouse));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            txtCount1.Text = "0";
            MessageBox.Show("Товар Распределён", "Уведомление", MessageBoxButton.OK);
            txtPosition.Text = "";
            cmbMaterial.SelectedIndex = cmbMaterial.SelectedIndex + 1;
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ExpenseComposition c = cmbMaterial.SelectedItem as ExpenseComposition;
            if (txtSearch.Text.Count() != 0)
                dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial && x.Warehouse.Name.ToLower().Contains(txtSearch.Text.ToLower())).ToList();
            else dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial).ToList();
        }

        private void DgWarhouse_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            int quantity = 0;
            foreach (Storage s in dgWarhouse.ItemsSource)
                quantity += s.QuantityComposition;
            txtCount1.Text = quantity.ToString();

            if (txtCount.Text == txtCount1.Text)
            {
                txtPosition.Text = "Позиция закрыта";
                dgWarhouse.ItemsSource = (dgWarhouse.ItemsSource as List<Storage>).Where(x => x.QuantityComposition != 0).ToList();
                quantityComposition.IsReadOnly = true;
            }
        }
    }
}

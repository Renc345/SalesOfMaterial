﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для DistributionWarehouse.xaml
    /// </summary>
    public partial class DistributionWarehouse : Page
    {
        ExpenseIvoices expense = new ExpenseIvoices();
        public DistributionWarehouse(ExpenseIvoices selected)
        {
            InitializeComponent();
            if(selected != null)
            {
                expense = selected;
            }
            cmbMaterial.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == expense.IdExpenseIvoices).ToList();
            //LoadComboBox();
        }
        public void LoadComboBox()
        {
            List<Materials> list = new List<Materials>();
            foreach (ExpenseComposition e in ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == expense.IdExpenseIvoices).ToList())
            {
                Materials m = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials where idMaterial = @material", new SqlParameter("@material", e.IdMaterial)).FirstOrDefault();
                if (m != null) list.Add(m);
            }
            cmbMaterial.ItemsSource = list;
        }

        private void cmbMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ExpenseComposition c = cmbMaterial.SelectedItem as ExpenseComposition;
            dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial).ToList();
            txtCount.DataContext = ClassFrame.db.ExpenseComposition.FirstOrDefault(x => x.IdExpenseIvoices == expense.IdExpenseIvoices && x.IdMaterial == c.IdMaterial);
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            List<Storage> list = dgWarhouse.ItemsSource as List<Storage>;
            foreach (Storage s in list)
            {
                if (s.QuantityComposition == null)
                {
                    MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                if (s.QuantityComposition > s.Quantity)
                {
                    MessageBox.Show("Количество забираемого товара больше чем количество хранящиеся на складе", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (s.QuantityComposition > Convert.ToInt32(txtCount.Text))
                {
                    MessageBox.Show("Количество забираемого товара больше чем количество хранящиеся на складе", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

            }     
            foreach(Storage s in list)
            {
                try
                {
                    ClassFrame.db.Database.ExecuteSqlCommand("insert into Nomenclature.dbo.Movement values (@warehouse,@composition,@user,@quantity,1)", new SqlParameter("@warehouse", s.idWarehouse), new SqlParameter("@composition", ((ExpenseComposition)cmbMaterial.SelectedItem).IdExpenseComposition), new SqlParameter("@user", Users.GetUsers.ID), new SqlParameter("@quantity", s.QuantityComposition));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ExpenseComposition c = cmbMaterial.SelectedItem as ExpenseComposition;
            if (txtSearch.Text.Count() != 0)
                dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial && x.Warehouse.Name.ToLower().Contains(txtSearch.Text.ToLower())).ToList();
            else dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial).ToList();
        }
    }
}

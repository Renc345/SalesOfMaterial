﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для DistributionWarehouse.xaml
    /// </summary>
    public partial class DistributionWarehouse : Page
    {
        ExpenseIvoices expense = new ExpenseIvoices();
        public DistributionWarehouse(ExpenseIvoices selected)
        {
            InitializeComponent();
            if(selected != null)
            {
                expense = selected;
            }
            //dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList();
            //LoadDataGrid(ClassFrame.db.Database.SqlQuery<Movement>("select * from Nomenclature.dbo.Movement").ToList());
            LoadComboBox();
        }
        //public void LoadDataGrid(List<Movement> list)
        //{
        //    foreach (Movement m in list)
        //    {
        //        m.Warehouse = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses where idWarehouse = @id", new SqlParameter("@id", m.idWarehouse)).First();
        //        ExpenseComposition e = ClassFrame.db.ExpenseComposition.FirstOrDefault(x => x.IdExpenseComposition == m.idComposition);
        //        m.User = ClassFrame.db.Employee.FirstOrDefault(x => x.IdEmployee == m.idUser);
        //        e.ExpenseIvoices = ClassFrame.db.ExpenseIvoices.FirstOrDefault(x => x.IdExpenseIvoices == e.IdExpenseIvoices);
        //        m.Expense = e;
        //    }
        //    dgWarhouse.ItemsSource = list;
        //}
        //public void LoadDataGrid(List<Storage> list)
        //{
        //    foreach (Storage s in list)
        //    {
        //        s.Warehouse = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses where idWarehouse = @id", new SqlParameter("@id", s.idWarehouse)).First();
        //        s.Material = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials where idMaterial = @id", new SqlParameter("@id", s.idMaterial)).First();
        //    }
        //    dgWarhouse.ItemsSource = list;
        //}
        public void LoadComboBox()
        {
            List<Materials> list = new List<Materials>();
            foreach (ExpenseComposition e in ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == expense.IdExpenseIvoices).ToList())
            {
                Materials m = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials where idMaterial = @material", new SqlParameter("@material", e.IdMaterial)).FirstOrDefault();
                if (m != null) list.Add(m);
            }
            cmbMaterial.ItemsSource = list;
         
        }

        private void cmbMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Materials m = cmbMaterial.SelectedItem as Materials;
            dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == m.idMaterial).ToList();

            //string material = cmbMaterial.SelectedValue.ToString();
            //if (material != "Все материалы")
            //{
            //    dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == m.idMaterial).ToList();
            //}
            //else dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage");
        }
    }
}

﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddListOfMaterials.xaml
    /// </summary>
    public partial class PageAddListOfMaterials : Page
    {
        public Storage _currentItem = new Storage();
        public PageAddListOfMaterials(Storage selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
            }
            DataContext = _currentItem;
            cmbMaterial.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
            cmbWarehouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses").ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if ( cmbMaterial.Text == "" ||  cmbWarehouse.Text == "" || txtQuantity.Text == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Storage s = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage where idWarehouse = @warehouse and idMaterial = @material", new SqlParameter("@warehouse", _currentItem.idWarehouse), new SqlParameter("@material", _currentItem.idMaterial)).FirstOrDefault();
            if (s != null) _currentItem.idStorage = s.idStorage;
            _currentItem.idWarehouse =((Warehouses)cmbWarehouse.SelectedItem).idWarehouse;
            _currentItem.idMaterial = ((Materials)cmbMaterial.SelectedItem).idMaterial;
            _currentItem.Quantity = Convert.ToInt32(txtQuantity.Text);
            if(_currentItem.idStorage == 0) ClassFrame.db.Database.ExecuteSqlCommand("insert into Nomenclature.dbo.Storage values (@warhouse,@materials,@quantity)", new SqlParameter("@warhouse", _currentItem.idWarehouse), new SqlParameter("@materials", _currentItem.idMaterial), new SqlParameter("@quantity", _currentItem.Quantity));
            else ClassFrame.db.Database.ExecuteSqlCommand("update Nomenclature.dbo.Storage set idWarehouse = @warehouse, idMaterial = @material, Quantity = Quantity + @quantity where idStorage = @id", new SqlParameter("@warehouse", _currentItem.idWarehouse), new SqlParameter("@material", _currentItem.idMaterial), new SqlParameter("@quantity", _currentItem.Quantity), new SqlParameter("@id", _currentItem.idStorage));
            ClassFrame.frmObj.Navigate(new ListOfMaterials());
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ListOfMaterials());
        }
    }
}

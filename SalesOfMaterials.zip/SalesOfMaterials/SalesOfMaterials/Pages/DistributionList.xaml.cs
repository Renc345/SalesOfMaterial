﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для DistributionList.xaml
    /// </summary>
    public partial class DistributionList : Page
    {
        public DistributionList()
        {
            InitializeComponent();
            dgMovement.ItemsSource = ClassFrame.db.ExpenseComposition.ToList();
            cmbWarehouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses").ToList();
        }

        private void dgMovement_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
        }
    }
}

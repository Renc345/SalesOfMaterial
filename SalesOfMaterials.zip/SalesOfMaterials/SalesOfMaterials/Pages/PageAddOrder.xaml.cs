﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddOrder.xaml
    /// </summary>
    public partial class PageAddOrder : Page
    {
        public ExpenseIvoices _currentItem = new ExpenseIvoices();
        public PageAddOrder(ExpenseIvoices selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
            }
            DataContext = _currentItem;
            txtFIO.Text = Users.GetUsers.FIO;
            cmbСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
            
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ExpenseIvoices ivoices = new ExpenseIvoices();
            if (cmbСounterparties.Text == "" && datePicker1.Text == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;                   
            }
            Сounterparties сounterparties = (Сounterparties)cmbСounterparties.SelectedItem;
            ivoices.IdСounterparties = сounterparties.IdСounterparties;
            ivoices.IdEmployee = Users.GetUsers.ID;
            ivoices.Date_Transfer = datePicker1.SelectedDate;
            try
            {
                if (ivoices.IdExpenseIvoices == 0)
                {
                    ClassFrame.db.ExpenseIvoices.Add(ivoices);
                    ClassFrame.db.SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageAddExpenseComposition(ivoices));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}

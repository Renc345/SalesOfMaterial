﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMenu.xaml
    /// </summary>
    public partial class PageMenu : Page
    {
        public PageMenu()
        {
            InitializeComponent();
            switch (Users.GetUsers.IdTypesEmployee)
            {
                case 1:
                    Button btn = new Button() { Name = "btnDistribution", Width = 200, Height = 30, Content = "Список отдоваемых материалов" };
                    btn.Click += btnDistribution_Click;
                    stplButtons.Children.Add(btn);
                    Button btn2 = new Button() { Name = "btnMovment", Width = 200, Height = 30, Content = "Список отданных материалов", Margin = new Thickness(10) };
                    btn2.Click += btnMovment_Click;
                    stplButtons.Children.Add(btn2);
                    Button btn3 = new Button() { Name = "btnUser", Width = 200, Height = 30, Content = "Список пользователей" };
                    btn3.Click += btnUser_Click;
                    stplButtons.Children.Add(btn3);
                    break;
                case 3:
                    Button btn4 = new Button() { Name = "btnDistribution", Width = 200, Height = 30, Content = "Список отдоваемых материалов", Margin = new Thickness(10) };
                    btn4.Click += btnDistribution_Click;
                    stplButtons.Children.Add(btn4);
                    Button btn5 = new Button() { Name = "btnMovment", Width = 200, Height = 30, Content = "Список отданных материалов"};
                    btn5.Click += btnMovment_Click;
                    stplButtons.Children.Add(btn5);
                    break;
            }
        }

        private void btnorder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void btnListOfMaerials_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ListOfMaterials());
        }

        private void btnMaterials_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMaaterials());
        }

        private void btnPersonalAccount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PagePersonalAccount());
        }

        private void btnDistribution_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new DistributionList());
        }

        private void btnMovment_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Movment());
        }

        private void btnUser_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new User());
        }

        private void btnСounterparties_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Сounterparties());
        }
    }
}

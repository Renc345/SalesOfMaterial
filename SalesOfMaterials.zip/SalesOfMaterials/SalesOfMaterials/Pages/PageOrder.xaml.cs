﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            switch (Users.GetUsers.IdTypesEmployee)
            {
                case 1:
                    Button btn = new Button() { Name = "btnAddOrder", Width = 130, Height = 30, Content = "Добавить новый заказ", Margin = new Thickness(10) };
                    btn.Click += btnAddOrder_Click;
                    stplButtons.Children.Add(btn);
                    Button btn2 = new Button() { Name = "btnDistribution", Width = 130, Height = 30, Content = "Распределить", Margin = new Thickness(10) };
                    btn2.Click += btnDistribution_Click;
                    stplButtons.Children.Add(btn2);
                    break;
                case 2:
                    Button btn3 = new Button() { Name = "btnAddOrder", Width = 130, Height = 30, Content = "Добавить новый заказ", Margin = new Thickness(10) };
                    btn3.Click += btnAddOrder_Click;
                    stplButtons.Children.Add(btn3);
                    break;
                case 3:
                    Button btn4 = new Button() { Name = "btnDistribution", Width = 130, Height = 30, Content = "Распределить", Margin = new Thickness(10) };
                    btn4.Click += btnDistribution_Click;
                    stplButtons.Children.Add(btn4);
                    break;
            }
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            List<ExpenseIvoices> OrderForRemoving = dgExpenseIvoices.SelectedItems.Cast<ExpenseIvoices>().ToList();
            if (MessageBox.Show("Удалить заказы", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (ExpenseIvoices o in OrderForRemoving)
                    {
                        List<ExpenseComposition> list = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices).ToList();
                        foreach (ExpenseComposition c in list)
                            ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Movement where idComposition = @com and ArrivalOrExpenditure = 1", new SqlParameter("@com", c.IdExpenseComposition));
                        ClassFrame.db.ExpenseComposition.RemoveRange(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices));
                    }
                    ClassFrame.db.ExpenseIvoices.RemoveRange(OrderForRemoving);
                    ClassFrame.db.SaveChanges();
                }
                catch(Exception ex) 
                {
                    MessageBox.Show(ex.Message.ToString());
                    return;
                }
                MessageBox.Show("Данные удаленны");
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            }
        }

        private void dgExpenseIvoices_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(dgExpenseIvoices.SelectedItem != null)
                ClassFrame.frmObj.Navigate(new PageExpenseComposition((ExpenseIvoices)dgExpenseIvoices.SelectedItem));

        }

        private void btnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder(null));
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void TxtOrder_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtOrder.Text.Count() != 0)
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.Where(x => x.Employee.FIO.ToLower().Contains(TxtOrder.Text.ToLower()) || x.Сounterparties.Nazv_Сounterparties.ToLower().Contains(TxtOrder.Text.ToLower())).ToList();
            else dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void btnDistribution_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new DistributionWarehouse((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }
    }
    
}

﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            switch (Users.GetUsers.IdTypesEmployee)
            {
                case 1:
                    MenuItem item = new MenuItem() { Header = "Добавить новый заказ" };
                    item.Click += btnAddOrder_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2, item);
                    MenuItem item1 = new MenuItem() { Header = "Распределить" };
                    item1.Click += btnDistribution_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2,item1);
                    break;
                case 2:
                    MenuItem item2 = new MenuItem() { Header = "Добавить новый заказ" };
                    item2.Click += btnAddOrder_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2, item2);
                    break;
                case 3:
                    MenuItem item3 = new MenuItem() { Header = "Распределить" };
                    item3.Click += btnDistribution_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2, item3);
                    break;
            }
        }

        private void dgExpenseIvoices_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (dgExpenseIvoices.SelectedItem != null)
                ClassFrame.frmObj.Navigate(new PageExpenseComposition((ExpenseIvoices)dgExpenseIvoices.SelectedItem));

        }

        private void btnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder(null));
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void TxtOrder_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtOrder.Text.Count() != 0)
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.Where(x => x.Employee.FIO.ToLower().Contains(TxtOrder.Text.ToLower()) || x.Сounterparties.Nazv_Сounterparties.ToLower().Contains(TxtOrder.Text.ToLower())).ToList();
            else dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void btnDistribution_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new DistributionWarehouse((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            List<ExpenseIvoices> OrderForRemoving = dgExpenseIvoices.SelectedItems.Cast<ExpenseIvoices>().ToList();
            if (MessageBox.Show("Удалить заказы", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (ExpenseIvoices o in OrderForRemoving)
                    {
                        List<ExpenseComposition> list = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices).ToList();
                        foreach (ExpenseComposition c in list)
                            ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Movement where idComposition = @com and ArrivalOrExpenditure = 1", new SqlParameter("@com", c.IdExpenseComposition));
                        ClassFrame.db.ExpenseComposition.RemoveRange(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices));
                    }
                    ClassFrame.db.ExpenseIvoices.RemoveRange(OrderForRemoving);
                    ClassFrame.db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                    return;
                }
                MessageBox.Show("Данные удаленны");
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            }
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder(null));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
    
}

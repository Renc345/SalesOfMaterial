﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            List<ExpenseIvoices> OrderForRemoving = dgExpenseIvoices.SelectedItems.Cast<ExpenseIvoices>().ToList();
            if (MessageBox.Show("Удалить заказы", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (ExpenseIvoices o in OrderForRemoving)
                    {
                        foreach (ExpenseComposition c in ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices))
                            ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Movement where idComposition = @com and ArrivalOrExpenditure = 1", new SqlParameter("@com", c.IdExpenseComposition));
                        ClassFrame.db.ExpenseComposition.RemoveRange(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices));
                        ClassFrame.db.SaveChanges();
                    }
                    ClassFrame.db.ExpenseIvoices.RemoveRange(OrderForRemoving);
                    ClassFrame.db.SaveChanges();
                }
                catch(Exception ex) 
                {
                    MessageBox.Show(ex.Message.ToString());
                    return;
                }
                MessageBox.Show("Данные удаленны");
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            }
        }

        private void dgExpenseIvoices_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageExpenseComposition((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void btnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder(null));
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void TxtOrder_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtOrder.Text.Count() != 0)
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.Where(x => x.Employee.FIO.ToLower().Contains(TxtOrder.Text.ToLower()) || x.Сounterparties.Nazv_Сounterparties.ToLower().Contains(TxtOrder.Text.ToLower())).ToList();
            else dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.OrderBy(x => x.IdСounterparties).ToList();
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.OrderByDescending(x => x.IdСounterparties).ToList();
        }

        private void btnDistribution_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new DistributionWarehouse((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }
    }
    
}

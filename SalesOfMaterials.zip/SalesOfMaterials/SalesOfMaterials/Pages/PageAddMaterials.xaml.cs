﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddMaterials.xaml
    /// </summary>
    public partial class PageAddMaterials : Page
    {
        public Materials _currentItem = new Materials();
        public PageAddMaterials(Materials selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null) 
            {
                _currentItem = selectedItem;
            }
            DataContext = _currentItem;
            cmbTypes.ItemsSource = ClassFrame.db.Database.SqlQuery<Types>("select * from Nomenclature.dbo.Types").ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(txtNameMaterial.Text == "" || cmbTypes.Text == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            _currentItem.Name = txtNameMaterial.Text;
            _currentItem.idType = ((Types)cmbTypes.SelectedItem).idType;
            if (_currentItem.idType == 4) _currentItem.DrawingNumber = "Отсутствует";
            else _currentItem.DrawingNumber = txtDrawingNumber.Text;
            try
            {
                if (_currentItem.idMaterial == 0) ClassFrame.db.Database.SqlQuery<Materials>("insert into Nomenclature.dbo.Materials values (@name,@plan,@type)", new SqlParameter("@name", _currentItem.Name), new SqlParameter("@plan", _currentItem.DrawingNumber), new SqlParameter("@type", _currentItem.idType)).ToList();
                else ClassFrame.db.Database.SqlQuery<Materials>("update Nomenclature.dbo.Materials set Name = @name, DrawingNumber = @plan, idType = @type where idMaterial = @id", new SqlParameter("@name", _currentItem.Name), new SqlParameter("@plan", _currentItem.DrawingNumber), new SqlParameter("@type", _currentItem.idType), new SqlParameter("@id", _currentItem.idMaterial)).ToList();
                ClassFrame.frmObj.Navigate(new PageMaaterials());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMaaterials());
        }
    }
}

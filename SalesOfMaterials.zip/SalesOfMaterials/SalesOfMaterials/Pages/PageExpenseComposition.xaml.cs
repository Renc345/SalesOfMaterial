﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageExpenseComposition.xaml
    /// </summary>
    public partial class PageExpenseComposition : Page
    {

        public readonly ExpenseIvoices _ivoices = new ExpenseIvoices();
        public PageExpenseComposition(ExpenseIvoices ivoices)
        {
            InitializeComponent();
            _ivoices = ivoices;
            dgExpenseComposition.ItemsSource = LoadDataGrid();


        }
        public List<ExpenseComposition> LoadDataGrid()
        {
            List<ExpenseComposition> expenses = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == _ivoices.IdExpenseIvoices).ToList();
            foreach (ExpenseComposition e in expenses)
                e.Material = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials where idMaterial = @id", new SqlParameter("@id", e.IdMaterial)).First();
            return expenses;
        }


        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());

        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            var ExpenceCompositionRemoving = dgExpenseComposition.SelectedItems.Cast<ExpenseComposition>().ToList();
            if (MessageBox.Show("Удалить сщстав заказа", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ClassFrame.db.ExpenseComposition.RemoveRange(ExpenceCompositionRemoving);
                    ClassFrame.db.SaveChanges();
                    MessageBox.Show("Данные удаленны");
                    LoadDataGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void TxtExpenseComposition_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtExpenseComposition.Text.Count() != 0)
                dgExpenseComposition.ItemsSource = LoadDataGrid().Where(x => x.Material.Name.ToLower().Contains(TxtExpenseComposition.Text.ToLower()));
            else dgExpenseComposition.ItemsSource = LoadDataGrid();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            dgExpenseComposition.ItemsSource = LoadDataGrid().OrderBy(x => x.Material.Name);
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            dgExpenseComposition.ItemsSource = LoadDataGrid().OrderByDescending(x => x.Material.Name);
        }
    }
}

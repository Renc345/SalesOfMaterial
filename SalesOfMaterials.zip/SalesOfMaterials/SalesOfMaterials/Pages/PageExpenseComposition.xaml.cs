﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageExpenseComposition.xaml
    /// </summary>
    public partial class PageExpenseComposition : Page
    {

        public readonly ExpenseIvoices _ivoices = new ExpenseIvoices();
        public PageExpenseComposition(ExpenseIvoices ivoices)
        {
            InitializeComponent();
            ClassFrame.db.Database.SqlQuery<ClassMaterials>("select Name from Nomenclature.dbo.Materials").ToList();
            _ivoices = ivoices;
            List<ExpenseComposition> expenses = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == _ivoices.IdExpenseIvoices).ToList();
            foreach (ExpenseComposition e in expenses)  
                e.Material = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList().FirstOrDefault(x => x.idMaterial == e.IdMaterial);
            dgExpenseComposition.ItemsSource = ClassFrame.db.Database.SqlQuery<ClassMaterials>("select * from Nomenclature.dbo.Materials").ToList(); ;


        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());

        }
    }
}
